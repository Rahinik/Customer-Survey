﻿import { Grid, Page, Toolbar, ExcelExport, ExcelExportProperties, Filter, SortDirection, Sort, QueryCellInfoEventArgs, EJ2Intance, Selection, FilterType, Resize } from '@syncfusion/ej2-grids';
import { ClickEventArgs } from '@syncfusion/ej2-navigations';
import { DataManager, Query, UrlAdaptor } from '@syncfusion/ej2-data';
import { DateRangePicker } from '@syncfusion/ej2-calendars';
import { Tooltip, Dialog } from '@syncfusion/ej2-popups';
import { Chart, LineSeries, Category, DateTime, Legend, Tooltip, ILoadedEventArgs, ChartTheme, ColumnSeries } from '@syncfusion/ej2-charts';
import {
    AccumulationTheme, AccumulationChart, AccumulationLegend, PieSeries, AccumulationDataLabel, AccumulationTooltip,
    IAccAnimationCompleteEventArgs, AccPoints, IAccTextRenderEventArgs, AccumulationSelection,
    IAccLoadedEventArgs,
    Chart, BarSeries, DataLabel, Category,
    Tooltip, IPointRenderEventArgs, ILoadedEventArgs, ChartTheme
} from '@syncfusion/ej2-charts';
import { enableRipple } from '@syncfusion/ej2-base';
import { Browser } from '@syncfusion/ej2-base';
import { EmitType } from '@syncfusion/ej2-base';
import { compile } from '@syncfusion/ej2-base';

enableRipple(true);

AccumulationChart.Inject(AccumulationLegend, PieSeries, AccumulationDataLabel, AccumulationTooltip, AccumulationSelection);
Chart.Inject(BarSeries, Category, Tooltip, DataLabel);
Chart.Inject(LineSeries, Category, DateTime, Legend, Tooltip);
Chart.Inject(ColumnSeries, DataLabel, Category, Legend, Tooltip);

let bootstrapColors: string[] = ['#6a8894', '#1FA632', '#027ABB', '#00bdae'];

function getFontSizeForCenterTitle(width: number): string {
    if (width > 300) {
        return '13px';
    } else if (width > 250) {
        return '10px';
    } else {
        return '8px';
    }
}

function getFontSize(width: number): string {
    if (width > 300) {
        return '11px';
    } else if (width > 250) {
        return '8px';
    } else {
        return '6px';
    }
}


let emailTrackingDetails = [];
let emailsentcount = 0;
let surveycount = 0;
let platformName = "";
var emailTrackinglist = (<any>window).SurveyTrackingList;
Array.prototype.slice.call(emailTrackinglist).forEach(function (item) {

    emailTrackingDetails.push({ 'x': item.EmailSentCount, 'y': item.SurveyUpdatedCount });
    emailsentcount = item.EmailSentCount;
    surveycount = item.SurveyUpdatedCount;
    platformName = item.PlatformName;
});


let centerTitleemailTracking: HTMLDivElement = document.createElement('div') as HTMLDivElement;
centerTitleemailTracking.style.position = 'absolute';
centerTitleemailTracking.style.visibility = 'hidden';

centerTitleemailTracking.innerHTML = platformName;


let emailTrackingpiechart: AccumulationChart = new AccumulationChart({
    enableSmartLabels: true,
    selectionMode: 'Point',
    // Initialize the chart series
    series: [
        {
            dataSource: [
                { x: 'Survey Requested Count', y: emailsentcount, text: emailsentcount.toString() },
                { x: 'Survey Count', y: surveycount, text: surveycount.toString() },
            ],
            xName: 'x',
            yName: 'y', startAngle: 0,
            endAngle: 360, innerRadius: '40%', name: 'Survey'
            dataLabel: {
                visible: true, position: 'Inside',
                name: 'text',
                font: { color: 'white', fontWeight: '400', size: '14px' }
            }
        }
    ],
    legendSettings: {
        visible: true, toggleVisibility: false,
        position: 'Right', height: '28%', width: '44%'
    },
    // Triggered animation complete, text render and load event
    animationComplete: (args: IAccAnimationCompleteEventArgs) => {
        centerTitleemailTracking.style.fontSize = getFontSizeForCenterTitle(args.accumulation.initialClipRect.width);
        let rect: ClientRect = centerTitleemailTracking.getBoundingClientRect();
        centerTitleemailTracking.style.top = (args.accumulation.center.y - rect.height / 2) + 'px';
        centerTitleemailTracking.style.left = (args.accumulation.center.x - rect.width / 2) + 'px';
        centerTitleemailTracking.style.visibility = 'visible';
        let points: AccPoints[] = args.accumulation.visibleSeries[0].points;
        for (let point of points) {
            if (point.labelPosition === 'Outside' && point.labelVisible) {
                let label: Element = document.getElementById('emailTrackingContainer_datalabel_Series_0_text_' + point.index);
                label.setAttribute('fill', 'red');
            }
        }
    },
    textRender: (args: IAccTextRenderEventArgs) => {
        args.series.dataLabel.font.size = getFontSize(emailTrackingpiechart.initialClipRect.width);
        emailTrackingpiechart.animateSeries = true;
    },
    load: (args: IAccLoadedEventArgs) => {
        let selectedTheme: string = location.hash.split('/')[1];
        selectedTheme = selectedTheme ? selectedTheme : 'Material';
        args.accumulation.theme = <AccumulationTheme>(selectedTheme.charAt(0).toUpperCase() + selectedTheme.slice(1));
        args.accumulation.legendSettings.position = Browser.isDevice ? 'Bottom' : 'Right';
    },
    tooltip: { enable: true, format: '${point.x} : <b>${point.y}</b>' },

});

emailTrackingpiechart.appendTo('#emailTrackingContainer');
document.getElementById('emailTrackingContainer').appendChild(centerTitleemailTracking);


///customer rating

let CustomerRatingListDetails = [];
var customerRatingDetails = (<any>window).CustomerRatingList;
Array.prototype.slice.call(customerRatingDetails).forEach(function (item) {

    CustomerRatingListDetails.push({ 'x': item.CustomerEmail, 'y': item.Percentage, 'text': item.Percentage + '%'  });   
});


let centerTitleCustomerRating: HTMLDivElement = document.createElement('div') as HTMLDivElement;
centerTitleCustomerRating.style.position = 'absolute';
centerTitleCustomerRating.style.visibility = 'hidden';

centerTitleCustomerRating.innerHTML = "Customer Rating";
// issue type taskcount pie chart

let CustomerRatingpiechart: AccumulationChart = new AccumulationChart({
    enableSmartLabels: true,
    selectionMode: 'Point',
    // Initialize the chart series
    series: [
        {
            dataSource: CustomerRatingListDetails,
            xName: 'x',
            yName: 'y', startAngle: 0,
            endAngle: 360, innerRadius: '40%',
            dataLabel: {
                visible: true, position: 'Inside',
                name: 'text',
                font: { color: 'white', fontWeight: '400', size: '14px' }
            }
        }
    ],
    legendSettings: {
        visible: true, toggleVisibility: false,
        position: 'Right', height: '28%', width: '44%'
    },
    // Triggered animation complete, text render and load event
    animationComplete: (args: IAccAnimationCompleteEventArgs) => {
        centerTitleCustomerRating.style.fontSize = getFontSizeForCenterTitle(args.accumulation.initialClipRect.width);
        let rect: ClientRect = centerTitleCustomerRating.getBoundingClientRect();
        centerTitleCustomerRating.style.top = (args.accumulation.center.y - rect.height / 2) + 'px';
        centerTitleCustomerRating.style.left = (args.accumulation.center.x - rect.width / 2) + 'px';
        centerTitleCustomerRating.style.visibility = 'visible';
        let points: AccPoints[] = args.accumulation.visibleSeries[0].points;
        for (let point of points) {
            if (point.labelPosition === 'Outside' && point.labelVisible) {
                let label: Element = document.getElementById('customerRatingContainer_datalabel_Series_0_text_' + point.index);
                label.setAttribute('fill', 'red');
            }
        }
    },
    textRender: (args: IAccTextRenderEventArgs) => {
        args.series.dataLabel.font.size = getFontSize(CustomerRatingpiechart.initialClipRect.width);
        CustomerRatingpiechart.animateSeries = true;
    },
    load: (args: IAccLoadedEventArgs) => {
        let selectedTheme: string = location.hash.split('/')[1];
        selectedTheme = selectedTheme ? selectedTheme : 'Material';
        args.accumulation.theme = <AccumulationTheme>(selectedTheme.charAt(0).toUpperCase() + selectedTheme.slice(1));
        args.accumulation.legendSettings.position = Browser.isDevice ? 'Bottom' : 'Right';
    },
    tooltip: { enable: true, format: '${point.x} : <b>${point.y}</b>' },

});

CustomerRatingpiechart.appendTo('#customerRatingContainer');
document.getElementById('customerRatingContainer').appendChild(centerTitleCustomerRating);
