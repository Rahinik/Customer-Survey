﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SyncSurvey.Models;

namespace SyncSurvey.Controllers
{
    public class UserController : Controller
    {
        public ActionResult UserDetail()
        {
            return View();
        }

        public JsonResult UserCollection()
        {
            var details = new UserModel().GetCustomerDetail();
            return this.Json(new { result = details, count = details.Count }, JsonRequestBehavior.AllowGet);
        }
    }
}