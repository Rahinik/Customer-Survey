﻿using System;
using System.IO;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace SyncSurvey
{
    public class QuestionController : Controller
    {
        #region Constructor

        readonly IQuestion _question;        
        public QuestionController(IQuestion question)
        {
            _question= question;          
        }

        #endregion

        #region Question

        //[HttpPost]
        //public JsonResult GetQuestionDetailsForPurchasedCustomer()
        //{
        //    int type = 1;
        //    var result = _question.GetQuestionDetails(type);
        //    return Json(new { data = result }, JsonRequestBehavior.AllowGet);
        //}

        //[HttpPost]
        //public JsonResult GetQuestionDetailsForNonPurchasedCustomer()
        //{
        //    int type = 2;
        //    var result = _question.GetQuestionDetails(type);
        //    return Json(new { data = result }, JsonRequestBehavior.AllowGet);
        //}
        #endregion

    }
}