﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace SyncSurvey
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
            name: "User detail",
            url: "users",
            defaults: new { Controller = "User", action = "UserDetail" });

            routes.MapRoute(
            name: "Question details for purhased customer",
            url: "questionforpurchasedcustomer",
            defaults: new { Controller = "Question", action = "GetQuestionDetailsForPurchasedCustomer" });

            routes.MapRoute(
           name: "Question details for non purhased customer",
           url: "questionfornonpurchasedcustomer",
           defaults: new { Controller = "Question", action = "GetQuestionDetailsForNonPurchasedCustomer" });

            routes.MapRoute(
          name: "Survey",
          url: "survey",
          defaults: new { Controller = "Survey", action = "Survey" });

            routes.MapRoute(
            name: "User detail collection",
            url: "usercollection",
            defaults: new { Controller = "User", action = "UserCollection" });

            routes.MapRoute(
            name: "Mail notification",
            url: "mail",
            defaults: new { Controller = "Survey", action = "SendMailToGetFeedback" });

            routes.MapRoute(
            name: "Platform Survey",
            url: "platforms",
            defaults: new { Controller = "Survey", action = "Platforms" });

            routes.MapRoute(
           name: "Platform details Survey",
           url: "platforms/{platformName}",
           defaults: new { Controller = "Survey", action = "PlatformDetails" });

            routes.MapRoute(
                "Default",                                              // Route name
                "{controller}/{action}/{id}",                           // URL with parameters
                new { controller = "Home", action = "Index", id = "" }  // Parameter defaults
            );
        }
    }
}
