﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using SyncSurvey.Models;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Syncfusion.Customer.Base.Utils;
using SyncSurvey.Models.Objects;

namespace SyncSurvey.Controllers
{
    public class SurveyController : Controller
    {
       
        public SurveyController()
        {
        }

        readonly QuestionModel _question;
        public SurveyController(QuestionModel question)
        {
            _question = question;
        }

        public ActionResult Survey()
        {
            List<string> spliList1 = new List<string>();
            List<string> spliList2 = new List<string>();
            List<string> spliList3 = new List<string>();
            var idValue = 0;
            var emailAddress = string.Empty;
            string currentUrl = Request.Url.Query;
            currentUrl = currentUrl.Replace("?", string.Empty);
            currentUrl = RijndaelAlgorithm.Decrypt(currentUrl);
            if (!string.IsNullOrEmpty(currentUrl))
            {
                spliList1 = currentUrl.Split('&').ToList();

                if (spliList1.Count == 2)
                {
                    spliList2 = spliList1[0].Split('=').ToList();
                    spliList3 = spliList1[1].Split('=').ToList();
                }

                if (spliList2[0] == "id")
                {
                    idValue = Convert.ToInt32(spliList2[1]);
                }

                if (spliList3[0] == "email")
                {
                    emailAddress = spliList3[1];
                }
            }

            QuestionModel ques = new QuestionModel();
            var result = ques.GetQuestionDetails(idValue, emailAddress);
            ViewBag.CustomerId = idValue;
            ViewBag.IsCompleted = ques.IsAlreadySurveyCompleted(idValue);
            return this.View(result);
        }

        public ActionResult SendMailToGetFeedback(string Email, int Id)
        {
            SendMail sendMail = new SendMail();
            bool mailStatus = sendMail.sendMailToCustomers(Email, Id);
            return this.Json(new { result = true, JsonRequestBehavior.AllowGet });
        }
        
        [HttpPost]
        public ActionResult Survey(FormCollection formCollection)
        {
            var overallrating = formCollection["rating"];
            var customerId = formCollection["customerid"];
            var log = formCollection["question-answer"];
            dynamic result = JsonConvert.DeserializeObject<dynamic>(log);
            bool isSuccess = new QuestionModel().LogSurvey(result, overallrating, Convert.ToInt32(customerId));
            ViewBag.IsSuccess = isSuccess.ToString();
            ViewBag.IsCompleted = false;
            return View();
        }

        public ActionResult Platforms()
        {
            PlatformDetail platformDetail = new PlatformDetail();
            platformDetail.PlatformsRating = new QuestionModel().GetPlatformRating();
            return View(platformDetail);
        }

        public ActionResult PlatformDetails(string platformName)
        {
            PlatformDetail platformDetail = new PlatformDetail();          
            platformDetail.SurveyTracking = new QuestionModel().GetSurveyCount(platformName);
            platformDetail.CustomerRating = new QuestionModel().GetCustomerIndividualRating(platformName);
            return View(platformDetail);
        }
    }
}