﻿using NVelocity;
using Syncfusion.EmailSender.Base;
using Syncfusion.Customer.Base.Utils;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace SyncSurvey
{
    public class SendMail
    {
        public bool sendMailToCustomers(string Email, int Id)
        {
            try
            {
                VelocityContext context = new VelocityContext();
                string successMessage = string.Empty;
                string templateName = string.Empty;
                string format = "id="+ Id + "&email=" + Email;
                string decryptedEmail = RijndaelAlgorithm.Encrypt(format);
                context.Put("feedbackLink", "http://localhost:50165/survey?" + decryptedEmail);
                EmailGenerator.TemplateLocation = AppDomain.CurrentDomain.BaseDirectory + "EmailTemplate";
                templateName = "feedback.vm";
                string emailBody = EmailGenerator.ProcessTemplate(templateName, context);
                MailSender.SendMessage(Email, "Syncfusion : Survey", emailBody);
                using (var entity = new Entity())
                {
                    var questionDetails = (
                        from c in entity.SyncSurvey_Customers.Where(x => x.IsActive && x.Id == Id && x.EmailAddress == Email)
                        select c).FirstOrDefault();
                    questionDetails.IsEmailSent = true;
                    entity.SaveChanges();
                }

                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }

    }
}