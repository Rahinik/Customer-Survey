﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Net;
using System.Web;
using System.Configuration;
using System.Data.Entity;
using System.Reflection;
using SyncSurvey.Models.Objects;

namespace SyncSurvey
{
    public interface IQuestion
    {
        TransactionResult GetQuestionDetails(int id, string email);
    }

    public class QuestionModel : IQuestion
    {
        #region Constructor
       
        public QuestionModel()
        {
            
        }

        #endregion

        #region Question Details

        public TransactionResult GetQuestionDetails(int id, string email)
        {        
            var result = new TransactionResult();

            using (var context = new Entity())
            {           
                result.QuestionDetails = (
                    from c in context.SyncSurvey_Customers.Where(x => x.IsActive && x.Id == id && x.EmailAddress == email)
                    from i in context.SyncSurvey_Questions.Where(x => x.IsActive && x.TypeId == c.TypeId)
                    select new QuestionObjects()
                    {
                        QuestionId = i.Id,
                        QuestionName = i.Question,
                        Options = (from j in context.SyncSurvey_AnswerMapper.Where(x=> x.IsActive && x.QuestionId == i.Id)
                                   select j.Answer).ToList()
                    }).ToList();
                
            }

            return result;
        }

        public bool LogSurvey(dynamic details, string rating, int id)
        {
            bool isSuccess = false;
            using (var context = new Entity())
            {
                for (int i=0; i < details.Count; i++)
                {
                    int questionId = Convert.ToInt32(details[i]);
                    string answerName = details[i + 1];
                    answerName = answerName.Replace("-", " ");
                    int answerId = (from answer in context.SyncSurvey_AnswerMapper
                                    where answer.Answer == answerName && answer.QuestionId == questionId && answer.IsActive
                                    select answer.Id).FirstOrDefault();
                    if (answerId <= 0)
                    {
                        answerId = (from answer in context.SyncSurvey_AnswerMapper
                                    where answer.Answer == "Not Satisfied" && answer.QuestionId == questionId && answer.IsActive
                                    select answer.Id).FirstOrDefault();
                    }

                    i++;
                    SyncSurvey_FeedbackLog feedbackLog = new SyncSurvey_FeedbackLog()
                    {
                        CustomerId = id,
                        QuestionId = questionId,
                        AnswerId = answerId,
                        Rating = 0,
                        IsActive = true
                    };

                    context.SyncSurvey_FeedbackLog.Add(feedbackLog);
                }

                if (!string.IsNullOrEmpty(rating))
                {
                    SyncSurvey_FeedbackLog feedbackLogRating = new SyncSurvey_FeedbackLog()
                    {
                        CustomerId = id,
                        Rating = Convert.ToInt32(rating),
                        IsActive = true
                    };

                    context.SyncSurvey_FeedbackLog.Add(feedbackLogRating);
                    context.SaveChanges();
                }

                var customerDetails = (from customer in context.SyncSurvey_Customers
                                       where customer.Id == id && customer.IsActive select customer).FirstOrDefault();

                customerDetails.IsSurveyUpdated = true;
                context.SaveChanges();

                isSuccess = true;
            }

            return isSuccess;
        }       

        public bool IsAlreadySurveyCompleted(int id)
        {
            bool completed = false;

            using (var context = new Entity())
            {
                completed = (
                    from c in context.SyncSurvey_Customers.Where(x => x.IsActive && x.Id == id)
                    select c.IsSurveyUpdated).FirstOrDefault();
            }

            return completed;
        }

        public List<PlatformsRating> GetPlatformRating()
        {
            List<PlatformsRating> platformRating = new List<PlatformsRating>();
            double percentage = 0;
            using (var context = new Entity())
            {
               var platforms = (from platform in context.SyncSurvey_Customers
                 select new PlatformsRating
                 {
                     PlatformName = platform.PlatformName
                 }).Distinct().ToList();


                foreach(var platform in platforms)
                {
                    var Rating = (from log in context.SyncSurvey_FeedbackLog
                                  join customers in context.SyncSurvey_Customers on log.CustomerId equals customers.Id
                                  where customers.PlatformName == platform.PlatformName && log.Rating > 0 && log.IsActive
                                  select log.Rating.Value).ToList();

                    double average = Rating!= null && Rating.Count > 0 ? Rating.Average(): 0;
                    percentage = 0;
                    if (average > 0)
                    {
                        percentage = (average / 5) * 100;
                    }
                    percentage = Math.Round(percentage);

                    PlatformsRating platformRatingS = new PlatformsRating();
                    platformRatingS.PlatformName = platform.PlatformName;
                    platformRatingS.Percentage = percentage;
                    platformRating.Add(platformRatingS);
                }                                
            }

            return platformRating;
        }       

        public List<SurveyTracking> GetSurveyCount(string platformName)
        {
            List<SurveyTracking> surveyTracking = new List<SurveyTracking>();
            int surveyCount = 0;
            int emailCount = 0;
            platformName = GetPlatformDisplayName(platformName);
            using (var context = new Entity())
            {
                surveyCount = (from customer in context.SyncSurvey_Customers
                         where customer.IsSurveyUpdated && customer.PlatformName == platformName && customer.IsActive
                         select customer).Count();

                emailCount = (from customer in context.SyncSurvey_Customers
                         where customer.IsEmailSent && customer.PlatformName == platformName && customer.IsActive
                         select customer).Count();
            }

            SurveyTracking survey = new SurveyTracking();            
            survey.PlatformName = platformName;
            survey.SurveyUpdatedCount = surveyCount;
            survey.EmailSentCount = emailCount;
            surveyTracking.Add(survey);
            return surveyTracking;
        }

        public List<CustomerRating> GetCustomerIndividualRating(string platformName)
        {
            List<CustomerRating> customerRating = new List<CustomerRating>();
            double percentage = 0.00;
            List<int> ratingList = new List<int>();
            platformName = GetPlatformDisplayName(platformName);
            using (var context = new Entity())
            {
                var customers = (from customer in context.SyncSurvey_Customers
                                 where customer.PlatformName == platformName && customer.IsActive
                                 select new CustomerRating
                                 {
                                     CustomerEmail = customer.EmailAddress,
                                     CustomerId = customer.Id
                                 }).Distinct().ToList();

                foreach(var customer in customers)
                {
                    var rating = (from feedback in context.SyncSurvey_FeedbackLog
                                  join answers in context.SyncSurvey_AnswerMapper on feedback.AnswerId equals answers.Id
                                  where feedback.CustomerId == customer.CustomerId && feedback.AnswerId > 0 && feedback.IsActive
                                  select answers.Answer).ToList();

                    foreach (var ratingScenario in rating)
                    {
                        if (ratingScenario == "Extremely well")
                        {
                            ratingList.Add(5);
                        }
                        else if (ratingScenario == "Good")
                        {
                            ratingList.Add(4);
                        }
                        else if (ratingScenario == "Satisfied")
                        {
                            ratingList.Add(3);
                        }
                        else if (ratingScenario == "Not Satisfied")
                        {
                            ratingList.Add(1);
                        }
                    }

                    var Rating = (from feedback in context.SyncSurvey_FeedbackLog
                                  where feedback.CustomerId == customer.CustomerId && feedback.Rating > 0 && feedback.IsActive
                                  select feedback.Rating.Value).FirstOrDefault();

                    ratingList.Add(Rating);

                    double average = ratingList != null && ratingList.Count > 0 ? ratingList.Average() : 0;
                    percentage = 0;
                    if (average > 0)
                    {
                        percentage = (average / 5) * 100;
                    }
                    percentage = Math.Round(percentage);

                    CustomerRating customerRatings = new CustomerRating();
                    customerRatings.CustomerEmail = customer.CustomerEmail;
                    customerRatings.Percentage = percentage;
                    customerRating.Add(customerRatings);
                }
            }
           
            return customerRating;
        }

        public string GetPlatformDisplayName(string platformName)
        {
            if (platformName == "aspnetmvc")
            {
                platformName = "ASP.NET MVC";
            }
            else if (platformName == "aspnetcore")
            {
                platformName = "ASP.NET Core";
            }
            else if (platformName == "xamarin")
            {
                platformName = "Xamarin";
            }
            else if (platformName == "javascript")
            {
                platformName = "JavaScript";
            }
            else if (platformName == "uwp")
            {
                platformName = "UWP";
            }

            return platformName;
        }

        #endregion      
    }
}