﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SyncSurvey.Models.Objects
{
    public class TransactionResult
    {
        public List<QuestionObjects> QuestionDetails { get; set; }

        public bool IsSuccess { get; set; }
    }

    public class QuestionObjects
    {
        public int QuestionId { get; set; }

        public string QuestionName { get; set; }

        public List<string> Options { get; set; }        
    }

    public class QuestionAnswerMapping
{
        public int QuestionId { get; set; }

        public string AnswerName { get; set; }
    }

    public class PlatformsRating
    {
        public string PlatformName { get; set; }

        public double Percentage { get; set; }

        public  double Average { get; set; }

        public List<int> Rating { get; set; }
    }

    public class EmailTracking
    {
        public string PlatformName { get; set; }

        public int Count { get; set; }
    }

    public class SurveyTracking
    {
        public string PlatformName { get; set; }

        public int EmailSentCount { get; set; }

        public int SurveyUpdatedCount { get; set; }
    }

    public class CustomerRating
    {
        public string CustomerEmail { get; set; }

        public int CustomerId { get; set; }

        public double Percentage { get; set; }
    }

    public class PlatformDetail
    {
        public List<PlatformsRating> PlatformsRating { get; set; }
        public List<EmailTracking> EmailTracking { get; set; }

        public List<SurveyTracking> SurveyTracking { get; set; }

        public List<CustomerRating> CustomerRating { get; set; }
    }
}