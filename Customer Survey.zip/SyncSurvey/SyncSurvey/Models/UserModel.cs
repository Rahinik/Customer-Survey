﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SyncSurvey.Models
{
    public class UserModel
    {
        /// <summary>
        /// Get customer details
        /// </summary>
        public List<UserDetail> GetCustomerDetail()
        {
            List<UserDetail> userDetail = new List<UserDetail>();
            using (var context = new Entity())
            {
                userDetail = (from user in context.SyncSurvey_Customers
                              join type in context.SyncSurvey_CustomersType on user.TypeId equals type.Id
                              where user.IsActive && !user.IsEmailSent
                              orderby user.Name
                              select new UserDetail()
                              {
                                  CustomerEmail = user.EmailAddress,
                                  CustomerName = user.Name,
                                  Type = type.TypeName,
                                  Id = user.Id
                              }).ToList();
            }

            return userDetail;
        }
    }

    public class UserDetail
    {
        /// <summary>
        /// Gets or sets a value of the Id.The member declare as public.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets a value of the CustomerName.The member declare as public.
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets a value of the CustomerEmail.The member declare as public.
        /// </summary>
        public string CustomerEmail { get; set; }

        /// <summary>
        /// Gets or sets a value of the Type.The member declare as public.
        /// </summary>
        public string Type { get; set; }
    }
}