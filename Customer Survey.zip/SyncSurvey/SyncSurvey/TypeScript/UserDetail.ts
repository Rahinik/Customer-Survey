﻿import { Grid, Page, Toolbar, ExcelExport, ExcelExportProperties, Filter, SortDirection, Sort, QueryCellInfoEventArgs, EJ2Intance, Selection, FilterType, Resize } from '@syncfusion/ej2-grids';
import { ClickEventArgs } from '@syncfusion/ej2-navigations';
import { DataManager, Query, UrlAdaptor } from '@syncfusion/ej2-data';
import { DateRangePicker } from '@syncfusion/ej2-calendars';
import { Tooltip, Dialog } from '@syncfusion/ej2-popups';
﻿import { DatePicker, RenderDayCellEventArgs } from '@syncfusion/ej2-calendars';

$("#spinner-overlay").addClass("hide").removeClass("show");
$("#consentlist").removeClass('hide');

let Email: any;
let Id: any;
let data = new DataManager({
    url: '/usercollection',
    adaptor: new UrlAdaptor
});

Grid.Inject(Page, Toolbar, ExcelExport, Filter, Sort, Page, Selection, Resize);

// Proforma Order Date Picker
let datePicker: DatePicker = new DatePicker({
    value: new Date(),
    cssClass: 'e-customStyle'
});
datePicker.appendTo('#datepicker');

let grid: Grid = new Grid({
    dataSource: data,
    allowExcelExport: true,
    allowSelection: true,
    gridLines: 'Both',
    allowTextWrap: true,
    textWrapSettings: { wrapMode: 'Content' },
    allowResizing: true,
    filterSettings: { type: 'Excel' },
    columns: [
        { headerText: "CustomerName", field: "CustomerName", width: 35, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "CustomerEmail", field: "CustomerEmail", width: 45, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "Type", field: "Type", width: 35, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "Action", width: 20, allowSorting: false, allowFiltering: false, textAlign: 'center' },
    ],
    allowPaging: true,
    allowFiltering: true,
    allowSorting: true,
    pageSettings: { pageSize: 50 },
    queryCellInfo: function (args: QueryCellInfoEventArgs) {
        if (args.column.headerText == 'Type') {
            if (args.data['Type'] == "Purchased") {
                var $element = $(args.cell);
                $element.css("color", "Green");
            }
            else {
                var $element = $(args.cell);
                $element.css("color", "Red");
            }
        }

        if (args.column.headerText == 'Action') {
            args.cell.innerHTML = '<span title="Send Email" style="cursor:pointer" onclick="DialogOnClick(&quot;' + args.data['CustomerEmail'] + '&quot;,&quot;' + args.data['Id'] + '&quot;)"><i class="fa fa-envelope"></i></span> | <span title= "Setting" style= "cursor:pointer" onclick= "OnClick()" > <i class="fa fa-cog"></i></span>'
        }
    },
    excelExportComplete: function () {

    },
    beforeExcelExport: function () {

    }
});
grid.appendTo('#consentcollection');

function SetHyperLinkInGridTemplate(displayText, Url) {
    return '<a target="_blank" href="' + Url + '">' + displayText + '</a>';
}

// ===== Export function =====
grid.toolbarClick = (args: Object) => {
    if (args['item'].id === 'consentcollection_excelexport') {
        let excelExportProperties: ExcelExportProperties = {
            fileName: "Cookie Consent.xlsx",
            theme:
            {
                header: { bold: true },
            }
        };
        grid.excelExport(excelExportProperties);
    }
};

// dialog box
let browserDialog = new Dialog({
    showCloseIcon: true,
    closeOnEscape: true,
    isModal: true,
    position: { X: 'center', Y: 'center' },
    overlayClick: () => {
        browserDialog.hide();
    },
    buttons: [
        {
            'click': () => {
                MailProcess(Email, Id);
            },
            buttonModel: {
                content: 'Yes',
                cssClass: 'e-flat'
            }
        },
        {
            'click': () => {
                browserDialog.hide();
            },
            buttonModel: {
                content: 'No',
                cssClass: 'e-flat'
            }
        }
    ],
    width: '400px',
    height: '160px'
});
browserDialog.appendTo("#dialog");
browserDialog.hide();


// browser header Column click function
(<any>window).DialogOnClick = (email, id) => {
    Email = email;
    Id = id;
    var offsets = $('#consent-list').offset();
    var top = offsets.top;
    $("#dialog").css("top", top);
    $("#dialog").css("left", "auto");
    $("#dialog").removeClass("hide");
    browserDialog.show();
}

(<any>window).MailProcess = (Email, Id) => {
    $("#spinner-overlay").addClass("show").removeClass("hide");
    let data: any = JSON.stringify({ "Email": Email, "Id": Id });
    $.ajax({
        type: "POST",
        url: "/mail",
        data: data,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        error: function () {
            $("#spinner-overlay").addClass("hide").removeClass("show");
        },
        success: function (result) {
            browserDialog.hide();
            grid.refresh();
            $("#spinner-overlay").addClass("hide").removeClass("show");
        }
    });
};

// browser header Column click function
(<any>window).OnClick = () => {
    var offsets = $('#consent-list').offset();
    var top = offsets.top;
    $("#setting-dialog").css("top", top);
    $("#setting-dialog").css("left", "auto");
    $("#setting-dialog").removeClass("hide");
    settingDialog.show();
}

// dialog box
let settingDialog = new Dialog({
    header: 'Automation Setting',
    showCloseIcon: true,
    closeOnEscape: true,
    isModal: true,
    position: { X: 'center', Y: 'center' },
    overlayClick: () => {
        browserDialog.hide();
    },
    buttons: [
        {
            'click': () => {
                SettingClick();
            },
            buttonModel: {
                content: 'Save',
                cssClass: 'e-flat'
            }
        },
        {
            'click': () => {
                settingDialog.hide();
            },
            buttonModel: {
                content: 'Cancel',
                cssClass: 'e-flat'
            }
        }
    ],
    width: '600px',
    height: '200px'
});
settingDialog.appendTo("#setting-dialog");
settingDialog.hide();

(<any>window).SettingClick = () => {
    settingDialog.hide();
    $("#spinner-overlay").addClass("hide").removeClass("show");
    swal({
        title: "Automation setting has been saved successfully.",
    });
};