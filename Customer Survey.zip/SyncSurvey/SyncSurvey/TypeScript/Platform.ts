﻿import { Grid, Page, Toolbar, ExcelExport, ExcelExportProperties, Filter, SortDirection, Sort, QueryCellInfoEventArgs, EJ2Intance, Selection, FilterType, Resize } from '@syncfusion/ej2-grids';
import { ClickEventArgs } from '@syncfusion/ej2-navigations';
import { DataManager, Query, UrlAdaptor } from '@syncfusion/ej2-data';
import { DateRangePicker } from '@syncfusion/ej2-calendars';
import { Tooltip, Dialog } from '@syncfusion/ej2-popups';
import { Chart, LineSeries, Category, DateTime, Legend, Tooltip, ILoadedEventArgs, ChartTheme, ColumnSeries } from '@syncfusion/ej2-charts';
import {
    AccumulationTheme, AccumulationChart, AccumulationLegend, PieSeries, AccumulationDataLabel, AccumulationTooltip,
    IAccAnimationCompleteEventArgs, AccPoints, IAccTextRenderEventArgs, AccumulationSelection,
    IAccLoadedEventArgs,
    Chart, BarSeries, DataLabel, Category,
    Tooltip, IPointRenderEventArgs, ILoadedEventArgs, ChartTheme
} from '@syncfusion/ej2-charts';
import { enableRipple } from '@syncfusion/ej2-base';
import { Browser } from '@syncfusion/ej2-base';
import { EmitType } from '@syncfusion/ej2-base';
import { compile } from '@syncfusion/ej2-base';

enableRipple(true);

AccumulationChart.Inject(AccumulationLegend, PieSeries, AccumulationDataLabel, AccumulationTooltip, AccumulationSelection);
Chart.Inject(BarSeries, Category, Tooltip, DataLabel);
Chart.Inject(LineSeries, Category, DateTime, Legend, Tooltip);
Chart.Inject(ColumnSeries, DataLabel, Category, Legend, Tooltip);

let bootstrapColors: string[] = ['#6a8894', '#1FA632', '#027ABB', '#00bdae'];

//let result = [];
//result = [
//    { 'x': 'Net-tution and Fees', y: 21, text: '21%' },
//    { 'x': 'Self-supporting Operations', y: 21, text: '21%' },
//    { 'x': 'Private Gifts', y: 8, text: '8%' },
//    { 'x': 'All Other', y: 8, text: '8%' },
//    { 'x': 'Local Revenue', y: 4, text: '4%' },
//    { 'x': 'State Revenue', y: 21, text: '21%' },
//    { 'x': 'Federal Revenue', y: 16, text: '16%' }
//];

let PlatformsRatingListDetails = [];
var platformsRatingDetails = (<any>window).PlatformsRatingList;
Array.prototype.slice.call(platformsRatingDetails).forEach(function (item) {

    PlatformsRatingListDetails.push({ 'x': item.PlatformName, 'y': item.Percentage, 'text': item.Percentage + '%' });   
});

let centerTitle: HTMLDivElement = document.createElement('div') as HTMLDivElement;
centerTitle.style.position = 'absolute';
centerTitle.style.visibility = 'hidden'; 

centerTitle.innerHTML = "Platforms";
// issue type taskcount pie chart

let platformpiechart: AccumulationChart = new AccumulationChart({
    enableSmartLabels: true,
    selectionMode: 'Point',
    // Initialize the chart series
    series: [
        {
            dataSource: PlatformsRatingListDetails,
            xName: 'x',
            yName: 'y', startAngle: 0,
            endAngle: 360, innerRadius: '40%',
            dataLabel: {
                visible: true, position: 'Inside',
                name: 'text',
                font: { color: 'white', fontWeight: '400', size: '14px' }
            }
        }
    ],
    legendSettings: {
        visible: true, toggleVisibility: false,
        position: 'Right', height: '28%', width: '44%'
    },
    // Triggered animation complete, text render and load event
    animationComplete: (args: IAccAnimationCompleteEventArgs) => {
        centerTitle.style.fontSize = getFontSizeForCenterTitle(args.accumulation.initialClipRect.width);
        let rect: ClientRect = centerTitle.getBoundingClientRect();
        centerTitle.style.top = (args.accumulation.center.y - rect.height / 2) + 'px';
        centerTitle.style.left = (args.accumulation.center.x - rect.width / 2) + 'px';
        centerTitle.style.visibility = 'visible';
        let points: AccPoints[] = args.accumulation.visibleSeries[0].points;
        for (let point of points) {
            if (point.labelPosition === 'Outside' && point.labelVisible) {
                let label: Element = document.getElementById('container_datalabel_Series_0_text_' + point.index);
                label.setAttribute('fill', 'red');
            }
        }
    },
    textRender: (args: IAccTextRenderEventArgs) => {
        args.series.dataLabel.font.size = getFontSize(platformpiechart.initialClipRect.width);
        platformpiechart.animateSeries = true;
    },
    load: (args: IAccLoadedEventArgs) => {
        let selectedTheme: string = location.hash.split('/')[1];
        selectedTheme = selectedTheme ? selectedTheme : 'Material';
        args.accumulation.theme = <AccumulationTheme>(selectedTheme.charAt(0).toUpperCase() + selectedTheme.slice(1));
        args.accumulation.legendSettings.position = Browser.isDevice ? 'Bottom' : 'Right';
    },
    tooltip: { enable: true, format: '${point.x} : <b>${point.y}</b>' },

});

platformpiechart.appendTo('#platformcontainer');
document.getElementById('platformcontainer').appendChild(centerTitle);

function getFontSizeForCenterTitle(width: number): string {
    if (width > 300) {
        return '13px';
    } else if (width > 250) {
        return '10px';
    } else {
        return '8px';
    }
}

function getFontSize(width: number): string {
    if (width > 300) {
        return '11px';
    } else if (width > 250) {
        return '8px';
    } else {
        return '6px';
    }
}

