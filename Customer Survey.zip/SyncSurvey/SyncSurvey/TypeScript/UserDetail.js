"use strict";
var ej2_grids_1 = require('@syncfusion/ej2-grids');
var ej2_data_1 = require('@syncfusion/ej2-data');
var ej2_calendars_1 = require('@syncfusion/ej2-calendars');
var ej2_popups_1 = require('@syncfusion/ej2-popups');
$("#spinner-overlay").addClass("hide").removeClass("show");
$("#consentlist").removeClass('hide');
var start = new Date(new Date().setDate(new Date().getDate() - 6));
var end = new Date();
// Date picker
var dateRangePicker = new ej2_calendars_1.DateRangePicker({
    placeholder: 'Select a range',
    startDate: start,
    endDate: end,
    presets: [
        { label: 'Today', start: new Date(), end: new Date(new Date().setDate(new Date().getDate())) },
        { label: 'Last 7 Days', start: new Date(new Date().setDate(new Date().getDate() - 6)), end: new Date() },
        { label: 'This Month', start: new Date(new Date().setDate(1)), end: new Date(new Date(new Date(new Date().setMonth(new Date().getMonth() + 1)).setDate(0))) },
        { label: 'Last 30 Days', start: new Date(new Date().setDate(new Date().getDate() - 29)), end: new Date() },
        { label: 'Last Month', start: new Date(new Date(new Date().setMonth(new Date().getMonth() - 1)).setDate(1)), end: new Date(new Date().setDate(0)) },
        { label: 'Last 90 Days', start: new Date(new Date().setDate(new Date().getDate() - 89)), end: new Date() }
    ],
    change: function () {
        if (dateRangePicker.startDate != null && dateRangePicker.endDate != null) {
            grid.query.params[0]['value'] = dateRangePicker.startDate.toDateString();
            grid.query.params[1]['value'] = dateRangePicker.endDate.toDateString();
        }
        else {
            grid.query.params[0]['value'] = null;
            grid.query.params[1]['value'] = null;
        }
        grid.refresh();
    }
});
dateRangePicker.appendTo('#date-picker');
// Initialize grid
var query = new ej2_data_1.Query().addParams('ConsentStartDate', start).addParams('ConsentEndDate', end);
var data = new ej2_data_1.DataManager({
    url: '/cookieconsentcollection',
    adaptor: new ej2_data_1.UrlAdaptor
});
ej2_grids_1.Grid.Inject(ej2_grids_1.Page, ej2_grids_1.Toolbar, ej2_grids_1.ExcelExport, ej2_grids_1.Filter, ej2_grids_1.Sort, ej2_grids_1.Page, ej2_grids_1.Selection, ej2_grids_1.Resize);
var grid = new ej2_grids_1.Grid({
    dataSource: data,
    query: query,
    allowExcelExport: true,
    allowSelection: true,
    gridLines: 'Both',
    allowTextWrap: true,
    textWrapSettings: { wrapMode: 'Content' },
    toolbar: ['ExcelExport', 'Search'],
    allowResizing: true,
    filterSettings: { type: 'Excel' },
    columns: [
        { headerText: "UUID", field: "UUID", width: 45, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "Customer Id", field: "CustomerId", width: 35, type: 'number', clipMode: 'EllipsisWithTooltip' },
        { headerText: "Customer Name", field: "CustomerName", width: 40, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "Customer Email", field: "CustomerEmail", width: 45, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "KC", field: "KnownCompany", width: 30, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "Possible Company", field: "PossibleCompanyName", width: 30, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "IP", field: "IP", width: 40, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "Country", field: "Country", width: 30, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "Privacy Policy Version", field: "SyncfusionPolicyName", width: 30, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "Cookie Policy Version", field: "SyncfusionCookiePolicyName", width: 30, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "Origin", field: "Origin", width: 30, type: 'string', clipMode: 'EllipsisWithTooltip' },
        { headerText: "Browser Header", field: "BrowserHeader", width: 30, type: 'string', clipMode: 'EllipsisWithTooltip', allowSorting: false, allowFiltering: false, textAlign: 'Center' },
        { headerText: "Consent Date", field: "ConsentDate", width: 40, format: 'yMd', allowSorting: false, allowFiltering: false },
    ],
    allowPaging: true,
    allowFiltering: true,
    allowSorting: true,
    pageSettings: { pageSize: 50 },
    queryCellInfo: function (args) {
        if (args.column.headerText == 'Customer Id') {
            if (args.data['CustomerId'] == '' || args.data['CustomerId'] == null) {
                args.cell.innerHTML = '-';
            }
            else {
                args.cell.innerHTML = SetHyperLinkInGridTemplate(args.data['CustomerId'], '/customer/' + args.data['CustomerId']);
            }
        }
        if (args.column.headerText == 'Customer Email') {
            if (args.data['CustomerEmail'] == '' || args.data['CustomerEmail'] == null) {
                args.cell.innerHTML = '-';
            }
            else if (args.data['CustomerEmail'] != 'Deleted') {
                args.cell.innerHTML = SetHyperLinkInGridTemplate(args.data['CustomerEmail'], '/customer/' + args.data['CustomerId']);
            }
        }
        if (args.column.headerText == 'Customer Name') {
            if (args.data['CustomerName'] == '' || args.data['CustomerName'] == null) {
                args.cell.innerHTML = '-';
            }
            else {
                args.cell.innerHTML = args.data['CustomerName'];
            }
        }
        if (args.column.headerText == 'IP') {
            if (args.data['IP'] == '' || args.data['IP'] == null) {
                args.cell.innerHTML = '-';
            }
            else if (args.data['IP'] != 'Deleted') {
                args.cell.innerHTML = SetHyperLinkInGridTemplate(args.data['IP'], 'https://www.ip2location.com/demo/' + args.data['IP']);
            }
        }
        if (args.column.headerText == "Browser Header") {
            if (args.data['BrowserHeader'] != null && args.data['BrowserHeader'] != 'Deleted') {
                args.cell.innerHTML = '<a style="cursor:pointer" onclick="DialogOnClick(&quot;' + args.data['BrowserHeader'] + '&quot;, this)" > View </a>';
            }
            else {
                args.cell.innerHTML = '-';
            }
        }
        if (args.column.headerText == "KC") {
            if (args.data['KnownCompany'] != "Undefined" && args.data['KnownCompany'] != "Individual" && args.data['KnownCompany'] != "JunkKC" && args.data['KnownCompanyId'] > 0) {
                args.cell.innerHTML = SetHyperLinkInGridTemplate(args.data['KnownCompany'], '/knowncompany/' + args.data['KnownCompanyId']);
            }
            else if (args.data['KnownCompany'] == '' || args.data['KnownCompany'] == null) {
                args.cell.innerHTML = '-';
            }
            else if (args.data['KnownCompany'] == "Undefined") {
                args.cell.innerHTML = 'Undefined';
                var $element = $(args.cell);
                $element.css("color", "Red");
            }
            else {
                args.cell.innerHTML = args.data['KnownCompany'];
            }
        }
        if (args.column.headerText == "Possible Company") {
            if (args.data['PossibleCompanyName'] == null || args.data['PossibleCompanyName'] == "") {
                args.cell.innerHTML = '-';
            }
            else {
                args.cell.innerHTML = SetHyperLinkInGridTemplate(args.data['PossibleCompanyName'], '/possible-company/' + args.data['PossibleCompanyId']);
            }
        }
        if (args.column.headerText == "Privacy Policy Version") {
            if (args.data['SyncfusionPolicyLocation'] == null || args.data['SyncfusionPolicyLocation'] == "") {
                args.cell.innerHTML = args.data['SyncfusionPolicyName'];
            }
            else {
                args.cell.innerHTML = SetHyperLinkInGridTemplate(args.data['SyncfusionPolicyName'], args.data['SyncfusionPolicyLocation']);
            }
        }
        if (args.column.headerText == "Cookie Policy Version") {
            if (args.data['SyncfusionCookiePolicyLocation'] == null || args.data['SyncfusionCookiePolicyLocation'] == "") {
                args.cell.innerHTML = args.data['SyncfusionCookiePolicyName'];
            }
            else {
                args.cell.innerHTML = SetHyperLinkInGridTemplate(args.data['SyncfusionCookiePolicyName'], args.data['SyncfusionCookiePolicyLocation']);
            }
        }
        if (args.column.headerText == "UUID") {
            args.cell.innerHTML = SetHyperLinkInGridTemplate(args.data['UUID'], '/possible-company/activity?uuid=' + args.data['UUID']);
        }
    },
    excelExportComplete: function () {
        this.columns[0].width = '45';
        this.columns[1].width = '35';
        this.columns[2].width = '40';
        this.columns[3].width = '45';
        this.columns[4].width = '30';
        this.columns[5].width = '30';
        this.columns[6].width = '40';
        this.columns[7].width = '30';
        this.columns[8].width = '40';
        this.columns[9].width = '30';
        this.columns[10].width = '30';
        this.columns[11].width = '30';
        this.columns[12].width = '40';
        $("#spinner-overlay").addClass("hide").removeClass("show");
    },
    beforeExcelExport: function () {
        $("#spinner-overlay").addClass("show").removeClass("hide");
        this.columns[0].width = '150';
        this.columns[1].width = '150';
        this.columns[2].width = '150';
        this.columns[3].width = '150';
        this.columns[4].width = '150';
        this.columns[5].width = '150';
        this.columns[6].width = '150';
        this.columns[7].width = '150';
        this.columns[8].width = '150';
        this.columns[9].width = '150';
        this.columns[10].width = '150';
        this.columns[11].width = '150';
        this.columns[12].width = '150';
    }
});
grid.appendTo('#consentcollection');
function SetHyperLinkInGridTemplate(displayText, Url) {
    return '<a target="_blank" href="' + Url + '">' + displayText + '</a>';
}
// ===== Export function =====
grid.toolbarClick = function (args) {
    if (args['item'].id === 'consentcollection_excelexport') {
        var excelExportProperties = {
            fileName: "Cookie Consent.xlsx",
            theme: {
                header: { bold: true },
            }
        };
        grid.excelExport(excelExportProperties);
    }
};
// Browser Header - Dialog box
var browserDialog = new ej2_popups_1.Dialog({
    header: 'Browser Header',
    showCloseIcon: true,
    closeOnEscape: true,
    isModal: true,
    position: { X: 'center', Y: 'center' },
    overlayClick: function () {
        browserDialog.hide();
    },
    buttons: [
        {
            'click': function () {
                browserDialog.hide();
            },
            buttonModel: {
                content: 'Close',
                isPrimary: true,
                cssClass: 'e-flat'
            }
        }
    ],
    width: '1000px',
    height: '350px'
});
browserDialog.appendTo("#dialog");
browserDialog.hide();
// browser header Column click function
window.DialogOnClick = function (content) {
    var splitContent = content.split(';');
    var fullContent;
    for (var i = 0; i < splitContent.length; i++) {
        if (i == 0) {
            fullContent = splitContent[i] + '<br>';
        }
        else {
            fullContent += splitContent[i] + '<br>';
        }
    }
    browserDialog.content = fullContent;
    var offsets = $('#consent-list').offset();
    var top = offsets.top;
    $("#dialog").css("top", top);
    $("#dialog").css("left", "auto");
    $("#dialog").removeClass("hide");
    browserDialog.show();
};
// ===== Scroll to Top ==== 
function isScrolledIntoView(elem) {
    var $elem = $(elem);
    var $window = $(window);
    var docViewTop = $window.scrollTop();
    var docViewBottom = docViewTop + $window.height() + 30;
    var elemTop = $elem.offset().top;
    var elemBottom = elemTop + $elem.height();
    return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
}
$(window).scroll(function () {
    if ($(this).scrollTop() > 300) {
        if ($("footer").length) {
            if (isScrolledIntoView($("footer"))) {
                $('#return-to-top').css("bottom", $("footer").outerHeight() + 2 + "px");
            }
            else {
                $('#return-to-top').css("bottom", "5px");
            }
        }
        $('#return-to-top').fadeIn();
    }
    else {
        $('#return-to-top').fadeOut();
    }
});
$('#return-to-top').click(function () {
    $("html, body").animate({
        scrollTop: 50
    }, 600);
    return false;
});
